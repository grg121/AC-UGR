#!/bin/bash

for i in {1..100..1}
do
    echo tam: $i
    ./figura1O
    ./figura1mA
    ./figura1mB
    ./figura1mAB
done
